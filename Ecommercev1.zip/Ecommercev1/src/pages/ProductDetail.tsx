import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingCart, Star, Heart } from "lucide-react";

const ProductDetail = () => {
  const [quantity, setQuantity] = useState(1);
  
  // This would normally come from an API
  const product = {
    id: 1,
    name: "Wireless Headphones",
    price: 129.99,
    image: "/placeholder.svg",
    category: "Electronics",
    rating: 4.5,
    reviewCount: 128,
    description: "Experience premium sound quality with our wireless headphones. Featuring active noise cancellation, 30-hour battery life, and comfortable over-ear design for all-day listening.",
    features: [
      "Active Noise Cancellation",
      "30-hour battery life",
      "Bluetooth 5.0 connectivity",
      "Built-in microphone for calls",
      "Foldable design for easy storage"
    ]
  };

  const relatedProducts = [
    {
      id: 2,
      name: "Smart Watch",
      price: 199.99,
      image: "/placeholder.svg"
    },
    {
      id: 3,
      name: "Bluetooth Speaker",
      price: 79.99,
      image: "/placeholder.svg"
    },
    {
      id: 4,
      name: "Wireless Earbuds",
      price: 89.99,
      image: "/placeholder.svg"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
        {/* Product Image */}
        <div>
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-96 object-cover rounded-lg"
          />
        </div>
        
        {/* Product Info */}
        <div>
          <div className="mb-4">
            <span className="text-sm text-blue-600 font-medium">{product.category}</span>
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            <div className="flex items-center mb-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-5 h-5 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                  />
                ))}
              </div>
              <span className="ml-2 text-gray-600">
                {product.rating} ({product.reviewCount} reviews)
              </span>
            </div>
            <p className="text-3xl font-bold mb-6">${product.price.toFixed(2)}</p>
            <p className="text-gray-700 mb-6">{product.description}</p>
          </div>
          
          <div className="mb-6">
            <h3 className="font-semibold mb-2">Key Features:</h3>
            <ul className="list-disc pl-5 space-y-1">
              {product.features.map((feature, index) => (
                <li key={index} className="text-gray-700">{feature}</li>
              ))}
            </ul>
          </div>
          
          <div className="flex items-center mb-8">
            <div className="flex items-center border rounded-md mr-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="h-10 w-10 p-0"
              >
                -
              </Button>
              <span className="px-4">{quantity}</span>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setQuantity(quantity + 1)}
                className="h-10 w-10 p-0"
              >
                +
              </Button>
            </div>
            <Button className="flex-grow">
              <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
            </Button>
            <Button variant="outline" size="icon" className="ml-4">
              <Heart className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Related Products */}
      <div>
        <h2 className="text-2xl font-bold mb-6">Related Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {relatedProducts.map((relatedProduct) => (
            <Card key={relatedProduct.id}>
              <CardContent className="p-4">
                <img 
                  src={relatedProduct.image} 
                  alt={relatedProduct.name} 
                  className="w-full h-40 object-cover rounded-md mb-4"
                />
                <h3 className="font-semibold mb-1">{relatedProduct.name}</h3>
                <p className="text-lg font-bold">${relatedProduct.price.toFixed(2)}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;