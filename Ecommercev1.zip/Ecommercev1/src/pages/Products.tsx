import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { ShoppingCart, Filter } from "lucide-react";

const Products = () => {
  const [priceRange, setPriceRange] = useState([0, 500]);
  
  const products = [
    {
      id: 1,
      name: "Wireless Headphones",
      price: 129.99,
      image: "/placeholder.svg",
      category: "Electronics",
      rating: 4.5
    },
    {
      id: 2,
      name: "Smart Watch",
      price: 199.99,
      image: "/placeholder.svg",
      category: "Electronics",
      rating: 4.8
    },
    {
      id: 3,
      name: "Bluetooth Speaker",
      price: 79.99,
      image: "/placeholder.svg",
      category: "Electronics",
      rating: 4.3
    },
    {
      id: 4,
      name: "Running Shoes",
      price: 89.99,
      image: "/placeholder.svg",
      category: "Sports",
      rating: 4.6
    },
    {
      id: 5,
      name: "Coffee Maker",
      price: 59.99,
      image: "/placeholder.svg",
      category: "Home & Kitchen",
      rating: 4.2
    },
    {
      id: 6,
      name: "Backpack",
      price: 39.99,
      image: "/placeholder.svg",
      category: "Clothing",
      rating: 4.0
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <h1 className="text-3xl font-bold">All Products</h1>
        <div className="flex items-center space-x-2 mt-4 md:mt-0">
          <span>Sort by:</span>
          <select className="border rounded px-2 py-1">
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
            <option>Top Rated</option>
          </select>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="flex items-center mb-4">
              <Filter className="mr-2" />
              <h2 className="text-lg font-semibold">Filters</h2>
            </div>
            
            <div className="mb-6">
              <Label className="mb-2 block">Price Range</Label>
              <Slider 
                defaultValue={priceRange} 
                max={500} 
                step={10} 
                onValueChange={(value) => setPriceRange(value as [number, number])}
                className="mb-2"
              />
              <div className="flex justify-between text-sm text-gray-600">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
              </div>
            </div>
            
            <div className="mb-6">
              <Label className="mb-2 block">Categories</Label>
              <div className="space-y-2">
                {["Electronics", "Clothing", "Home & Kitchen", "Sports"].map((category) => (
                  <div key={category} className="flex items-center">
                    <input type="checkbox" id={category} className="mr-2" />
                    <Label htmlFor={category}>{category}</Label>
                  </div>
                ))}
              </div>
            </div>
            
            <Button className="w-full">Apply Filters</Button>
          </div>
        </div>

        {/* Products Grid */}
        <div className="flex-grow">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <Card key={product.id} className="flex flex-col">
                <CardHeader className="p-0">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                </CardHeader>
                <CardContent className="flex-grow">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold">{product.name}</h3>
                    <span className="text-lg font-bold">${product.price.toFixed(2)}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{product.category}</p>
                  <div className="flex items-center mb-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <span key={i} className={`text-sm ${i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300'}`}>
                          ★
                        </span>
                      ))}
                    </div>
                    <span className="text-sm text-gray-600 ml-2">({product.rating})</span>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">
                    <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Products;